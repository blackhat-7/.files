return {
  IndentBlanklineSpaceChar = { fg = C.grey_6, nocombine = true },
  IndentBlanklineChar = { fg = C.grey_6, nocombine = true },
  IndentBlanklineContextStart = { fg = C.grey_7, underline = true },
  IndentBlanklineContextChar = { fg = C.grey_7, nocombine = true },
  IndentBlanklineSpaceCharBlankline = { fg = C.grey_6, nocombine = true },
}
