return { FocusedSymbol = { fg = C.yellow, bg = C.none } }
